package crudifier

import (
	"errors"
	"fmt"
	"reflect"
	"strings"

	"github.com/dronm/crudifier/metadata"
	"github.com/dronm/crudifier/types"
)

func ParseLimitParams(dbLimit types.DBLimit, params CollectionParams) error {
	if dbLimit == nil {
		return fmt.Errorf(ErrLimitNotInit, "ParseLimitParams")
	}
	dbLimit.SetFrom(int(params.From))
	dbLimit.SetCount(int(params.Count))
	return nil
}

func ParseSorterParams(model types.DBModel, dbSorter types.DBSorters, params CollectionParams) error {
	modelMd, err := metadata.NewModelMetadata(model)
	if err != nil {
		return err
	}

	for _, sorter := range params.Sorter {
		fieldID := sorter.Field
		structFieldInd := strings.Index(fieldID, "->")
		if structFieldInd >= 0 {
			fieldID = fieldID[:structFieldInd]
		}
		if _, ok := modelMd.Fields[fieldID]; !ok {
			return fmt.Errorf(ErrNoFieldInMD, "ParseSorterParams", fieldID)
		}

		var sortDirect types.SQLSortDirect
		switch sorter.Direct {
		case SortParDesc:
			sortDirect = types.SQLSortDesc
		default:
			sortDirect = types.SQLSortAsc
		}

		if dbSorter == nil {
			return fmt.Errorf(ErrSorterNotInit, "ParseSorterParams")
		}
		dbSorter.Add(sorter.Field, sortDirect)
	}

	return nil
}

func ParseFilterParams(model types.DBModel, dbFilter types.DBFilters, params CollectionParams) error {
	modelMd, err := metadata.NewModelMetadata(model)
	if err != nil {
		return err
	}

	var errorList strings.Builder // validation errors

	// check if every filter field exists in dbSelect.Model
	for _, filter := range params.Filter {
		// join is common for all fields in this filter
		var join types.FilterJoin
		switch filter.Join {
		case FilterParJoinOr:
			join = types.SQLFilterJoinOr
		default:
			join = types.SQLFilterJoinAnd
		}

		// and filter value can be assigned to model field.
		for filterFieldID, filterField := range filter.Fields {
			// if filterField.Value == nil {
			// 	fmt.Println("ParseFilterParams skip nil value for field:",filterFieldID)
			// 	continue
			// }

			filterModelFieldID := filterFieldID

			//json field search
			structFieldInd := strings.Index(filterModelFieldID, "->")
			if structFieldInd >= 0 {
				filterModelFieldID = filterModelFieldID[:structFieldInd]
			}

			fieldMd, ok := modelMd.Fields[filterModelFieldID]
			if !ok {
				return fmt.Errorf(ErrNoFieldInMD, "ParseFilterParams", filterModelFieldID)
			}

			//nil values must be included!
			if filterField.Value != nil {
				if _, err := fieldMd.Validate(reflect.ValueOf(filterField.Value)); err != nil {
					if errorList.Len() > 0 {
						errorList.WriteString(" ")
					}
					errorList.WriteString(err.Error())
					continue
				}
			}

			// resolve operator
			var operator types.SQLFilterOperator
			switch filterField.Operator {
			case FilterOperParEq:
				operator = types.SQLFilterOperatorEq
			case FilterOperParLess:
				operator = types.SQLFilterOperatorLess
			case FilterOperParGr:
				operator = types.SQLFilterOperatorGr
			case FilterOperParLessEq:
				operator = types.SQLFilterOperatorLess
			case FilterOperParGrEq:
				operator = types.SQLFilterOperatorGrEq
			case FilterOperParLk:
				operator = types.SQLFilterOperatorLk
			case FilterOperParILk:
				operator = types.SQLFilterOperatorILk
			case FilterOperParNotEq:
				operator = types.SQLFilterOperatorNotEq
			case FilterOperParIs:
				operator = types.SQLFilterOperatorIs
			case FilterOperParIn:
				operator = types.SQLFilterOperatorIn
			case FilterOperParIncl:
				operator = types.SQLFilterOperatorIncl
			case FilterOperParAny:
				operator = types.SQLFilterOperatorAny
			case FilterOperParHas:
				operator = types.SQLFilterOperatorHas
			case FilterOperParOverlap:
				operator = types.SQLFilterOperatorOverlap
			case FilterOperParContains:
				operator = types.SQLFilterOperatorContains
			case FilterOperParTS:
				operator = types.SQLFilterOperatorTS
			}

			if dbFilter == nil {
				return fmt.Errorf(ErrFilterNotInit, "ParseFilterParams")
			}
			switch operator {
			case types.SQLFilterOperatorTS:
				dbFilter.AddFullTextSearch(filterFieldID, filterField.Value, join)
			case types.SQLFilterOperatorIncl:
				dbFilter.AddArrayInclude(filterFieldID, filterField.Value, join)
			case types.SQLFilterOperatorHas:
				dbFilter.AddColumnArrayInclude(filterFieldID, filterField.Value, join)
			default:
				dbFilter.Add(filterFieldID, filterField.Value, operator, join)
			}
			// if operator == types.SQL_FILTER_OPERATOR_TS {
			// 	dbFilter.AddFullTextSearch(filterFieldID, filterField.Value, join)
			// } else if operator == types.SQL_FILTER_OPERATOR_INCL {
			// 	dbFilter.AddArrayInclude(filterFieldID, filterField.Value, join)
			// } else {
			// 	dbFilter.Add(filterFieldID, filterField.Value, operator, join)
			// }
		}
	}

	if errorList.Len() > 0 {
		return errors.New(errorList.String())
	}

	return nil
}
